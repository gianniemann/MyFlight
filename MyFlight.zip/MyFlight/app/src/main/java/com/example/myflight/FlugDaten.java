package com.example.myflight;

public class FlugDaten {
    private int id;
    private String cityDE;
    private String std;
    private String etd;
    private String statusTextDE;
    private String flc;
    private String fln;
    private String airline;
    private String typ;
}
